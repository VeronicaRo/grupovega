<?php
/**
 * The template for displaying all single career
 *
 * @package consultivo
 */
get_header();
?>
<div class="container content-container">
    <div class="row">
        <?php get_template_part( 'template-parts/content-doctor/content'); ?>
    </div>
</div>
<?php
get_footer();
