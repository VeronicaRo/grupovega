<?php
/**
 * The template for displaying all single service
 *
 * @package consultivo
 */
get_header();
get_template_part( 'template-parts/content-services/content');
get_footer();
